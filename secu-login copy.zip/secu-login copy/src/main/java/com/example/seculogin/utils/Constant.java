package com.example.seculogin.utils;

public class Constant {
    public static final int PUBLIC_POST = 1;
    public static final int DRAFT_POST = 0;
}
