package com.example.seculogin.security;

import com.example.seculogin.entity.User;

public interface ICurrentUser {
    User getUser();
}
