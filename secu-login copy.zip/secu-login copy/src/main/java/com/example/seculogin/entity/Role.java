package com.example.seculogin.entity;

public enum Role {
    ADMIN,EDITOR,USER
}
