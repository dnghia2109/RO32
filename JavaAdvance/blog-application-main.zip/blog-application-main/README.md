## Ứng dụng Blog

### Chạy ứng dụng

Sau khi clone clone repo. Chạy ứng dụng trên IDE

- Trang user : `http://localhost:8080`
- Trang admin : `http://localhost:8080/admin/login`

Tài khoản, mật khẩu truy cập ADMIN :
- email : root@gmail.com
- password : 111

### Gửi email :
- Quên mật khẩu : `http://localhost:8080/admin/forgot-password`
- Xem email đã gửi tại đây : `http://103.237.147.34:1080`

### Import database
- Xem file `data.sql` trong repo ([Xem chi tiết](data.sql))
